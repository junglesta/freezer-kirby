<?php snippet('header') ?>
	
	<header class="home header cf" role="banner">

    <?php snippet('menu') ?>
    



    <span class="gohome cf">
      <figure class="illu classic">
        <?php include("assets/images/freezer-classic-qr.svg"); ?>
      </figure>
    </span>

    <!-- this handle svg changes on click -->
    <script type='text/javascript'> 
      


    // function toggle(id) {
    //    var e = document.getElementById(id);
    //    if(e.style.display == 'block')
    //       e.style.display = 'none';
    //    else
    //       e.style.display = 'block';
    // }

// still to test:
    // function toggle(id) {
    //   el = document.getElementById(id);
    //   el.style.display = (el.style.display == '') ? 'none' : ''
    // }



    // window.onload=function(){
      //   document.documentElement.addEventListener("click",
      //   clickHandler,
      //   false);

      //   function clickHandler(evt) {
      //     var newtarget = evt.target || event.target;
      //     var topmost = document.getElementById("use");
      //     topmost.setAttributeNS("http://www.w3.org/1999/xlink",
      //         "xlink:href",
      //         "#" + newtarget.id);
      //   }
      // } 


      

      //       function sho(idname) { 
      // document.getElementById(idname).style.display = "block"; 
      // } 

      // function hai(idname) { 
      //   document.getElementById(idname).style.display = "none"; 
      // }
    </script>

    

  </header>
  
  <main class="main home" role="main">

    <div class="text">
      
      <h1><?php echo $page->title()->html() ?></h1>
      
      <?php echo $page->text()->kirbytext() ?>
    
    </div>

    <?php snippet('projects') ?>

  </main>

<?php snippet('footer') ?>

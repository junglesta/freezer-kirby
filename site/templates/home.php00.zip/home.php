<?php snippet('header') ?>
	
	<header class="home header cf" role="banner">

    <?php snippet('menu') ?>
    



    <span class="gohome cf">
      <figure class="illu classic">
        <?php include("assets/images/freezer-classic-qr.svg"); ?>
      </figure>
    </span>

    <!-- this to handle svg changes on click -->
    <script type='text/javascript'> 
      window.onload=function(){
        document.documentElement.addEventListener("click",
        clickHandler,
        false);

        function clickHandler(evt) {
          var newtarget = evt.target || event.target;
          var topmost = document.getElementById("use");
          topmost.setAttributeNS("http://www.w3.org/1999/xlink",
              "xlink:href",
              "#" + newtarget.id);
        }
      } 
    </script>
    
<!--     <a class="gohome cf" href="<?php // echo url() ?>">
      <figure class="illu classic">
        <span class="home-logo-front"><?php // include("assets/images/freezer-classic-qr.svg"); ?></span>
        <span class="home-logo-back"><?php //include("assets/images/freezer-qr.svg"); ?></span>
      </figure>
    </a> -->

    

  </header>
  
  <main class="main home" role="main">

    <div class="text">
      
      <h1><?php echo $page->title()->html() ?></h1>
      
      <?php echo $page->text()->kirbytext() ?>
    
    </div>

    <?php snippet('projects') ?>

  </main>

<?php snippet('footer') ?>

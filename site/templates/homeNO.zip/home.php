<?php snippet('header') ?>
	
	<header class="home header cf" role="banner">

    <?php snippet('menu') ?>
    
    <span class="gohome illu cf">

        <svg id="svgout"></svg>

        <script type="text/javascript">

          var s = Snap("#svgout");
          var g = s.group();
          var tux = Snap.load("assets/images/freezer-qr.svg", function ( loadedFragment ) {
                                                          g.append( loadedFragment );
                                                          g.hover( hoverover, hoverout );
                                                          g.text(30,30, 'hover over me');
                                                  } );

          var hoverover = function() { g.animate({ transform: 's2r45,150,150' }, 1000, mina.bounce ) };
          var hoverout = function() { g.animate({ transform: 's1r0,150,150' }, 1000, mina.bounce ) };


          
          //Snap.load("assets/images/freezer-qr.svg", function (f) {
          // Note that we traverse and change attr before SVG
          // is even added to the page
          //f.selectAll();
          // g = f.select("g");
          // s.append(g);
          // });

          // draw a circle at coordinate 10,10 with radius of 10
          // var c = paper.circle(10, 10, 10);
          // c.node.onclick = function () {
          //     c.attr("fill", "red");
          // };



          // var s = Snap("#homesvg");
          // var fcl = Snap.load("assets/images/freezer-classic-qr.svg", function (loadedFragment ) {
          //     s.append( loadedFragment );
          //   } );
          // var logo = Snap("#freezer-classic");
          // var qr = Snap("#freezer-qr");



            // logo.node.onclick = function () {
            //   logo.attr("fill", "red");
            // };

        </script>

    </span>

    

  </header>
  
  <main class="main home" role="main">

    <div class="text">
      
      <h1><?php echo $page->title()->html() ?></h1>
      
      <?php echo $page->text()->kirbytext() ?>
    
    </div>

    <?php snippet('projects') ?>

  </main>

<?php snippet('footer') ?>
